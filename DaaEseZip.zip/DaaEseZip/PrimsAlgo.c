#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

void print(int n, int arr[])
{
    printf("\n");
    for (int i = 0; i < n; i++)
    {
        printf("%d ", arr[i]);
    }
    printf("\n");
}

void print_Matrix(int n, int arr[], int matrix[][20])
{
    printf(" ");
    for (int i = 0; i < n; i++)
    {
        printf("%d ", arr[i]);
    }
    printf("\n");
    for (int i = 0; i < n; i++)
    {
        printf("%d ", arr[i]);
        for (int j = 0; j < n; j++)
        {
            printf("%d ", matrix[i][j]);
        }
        printf("\n");
    }
}

void input(int n, int arr[])
{
    int ele, i, j, first;
    printf("Enter : ");
    for (i = 0; i < n; i++)
    {
        scanf("%d", &ele);
        arr[i] = ele;
    }
    return;
}

void link(int n, int arr[], int matrix[][20])
{
    int loop;
    int a, b, a_index, b_index, weight;
    printf("\nTotal no. of edges : ");
    scanf("%d", &loop);
    for (int k = 0; k < loop; k++)
    {
        printf("Link betw : ");
        scanf("%d %d", &a, &b);
        printf("Weight = ");
        scanf("%d", &weight);
        for (int i = 0; i < n; i++)
        {
            if (arr[i] == a)
            {
                a_index = i;
            }
            if (arr[i] == b)
            {
                b_index = i;
            }
        }
        matrix[a_index][b_index] = weight;
        matrix[b_index][a_index] = weight;
    }
}

void prim(int n, int arr[], int matrix[][20], int result[])
{
    int result_index = 0;
    int visited[n], count = 0, end, start, min;
    visited[0] = 0;
    while (count < n - 1)
    {
        min = INT_MAX;
        for (int i = 0; i <= count; i++)
        {
            for (int j = 0; j < n; j++)
            {
                if (matrix[visited[i]][j] != 0 && matrix[visited[i]][j] < min)
                {
                    start = visited[i];
                    end = j;
                    min = matrix[start][end];
                }
            }
        }
        result[result_index] = arr[start];
        result_index++;
        result[result_index] = arr[end];
        result_index++;
        result[result_index] = matrix[start][end];
        result_index++;
        for (int i = 0; i < n; i++)
        {
            matrix[i][end] = 0;
        }
        matrix[end][start] = 0;
        count++;
        visited[count] = end;
    }
}

int main()
{
    int n;
    printf("Total no. of elements : ");
    scanf("%d", &n);
    int arr[n];
    input(n, arr);
    int matrix[n][20], result[3 * (n - 1)];
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            matrix[i][j] = 0;
        }
    }
    link(n, arr, matrix);
    printf("\nThe Adjacency matrix is:\n");
    print_Matrix(n, arr, matrix);
    prim(n, arr, matrix, result);
    printf("\nMinimum Spanning Tree (MST) : \n");
    int cost = 0;
    for (int i = 0; i < 3 * (n - 1); i += 3)
    {
        printf("%d -- %d == %d\n", result[i], result[i + 1], result[i + 2]);
        cost += result[i + 2];
    }
    printf("\nTotal cost of MST : %d\n", cost);
    return 0;
}